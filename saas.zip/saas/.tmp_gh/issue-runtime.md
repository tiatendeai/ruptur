## Objetivo
Reduzir o risco estrutural do runtime sem reescrita grande.

## Entregas
- extrair persistência de estado para módulo dedicado
- escrita atômica de `warmup-state.json`
- formalizar contrato do estado
- unificar normalização/despacho de rotas
- smoke tests das rotas críticas
- padronizar logs operacionais e trilha auditável

## Critérios de aceite
- rotas críticas cobertas por smoke test
- persistência isolada e segura
- regressões de path detectáveis
