## Contexto
Consolidado do ciclo Maestro em `saas/docs/2026-03-25-maestro-compilado-saas.md`.

## Objetivo
Materializar o plano de 30 dias do SaaS Ruptur/Antigravity em entregas executáveis, com classificação explícita entre backlog, débito técnico e demandas novas.

## 20 subtarefas
- [ ] 1. Definir proposta de valor em 1 frase
- [ ] 2. Fechar ICP primário e secundário
- [ ] 3. Formalizar taxonomia backlog/debt/demanda/operação
- [ ] 4. Criar matriz de priorização executiva
- [ ] 5. Definir métricas mestras da operação
- [ ] 6. Criar checklist de ativação no dashboard
- [ ] 7. Implementar estados vazios inteligentes
- [ ] 8. Revisar microcopy de confiança em settings
- [ ] 9. Adicionar ajuda contextual nas telas críticas
- [ ] 10. Criar jornada mínima de primeiro valor
- [ ] 11. Extrair persistência do estado para módulo dedicado
- [ ] 12. Formalizar contrato de `warmup-state.json`
- [ ] 13. Unificar normalização e despacho de rotas
- [ ] 14. Criar smoke tests das rotas críticas
- [ ] 15. Padronizar logs operacionais e trilha auditável
- [ ] 16. Remover segredos hardcoded do código e scripts
- [ ] 17. Proteger rotas administrativas do runtime
- [ ] 18. Restringir CORS e adicionar headers mínimos de segurança
- [ ] 19. Criar pipeline mínimo de CI/CD com smoke + health gate
- [ ] 20. Formalizar rollback, runbook e matriz de ambientes

## Critérios de aceite
- backlog e tech debt classificados com labels corretos
- prioridades P0/P1/P2 claras
- dependências visíveis
- issues filhas vinculadas a este épico
