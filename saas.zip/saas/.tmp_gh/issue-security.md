## Objetivo
Endurecer a superfície do warmup/runtime antes do próximo release seguro.

## Entregas
- remover segredos hardcoded do código e scripts
- proteger rotas administrativas do runtime
- restringir CORS por ambiente
- adicionar headers mínimos de segurança
- planejar rate limiting e mascaramento de PII em logs

## Critérios de aceite
- nenhum segredo sensível em código versionado
- rotas críticas protegidas ou isoladas
- CORS/headers com postura mínima de produção
