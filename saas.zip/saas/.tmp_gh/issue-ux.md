## Objetivo
Melhorar ativação, estados vazios, confiança e orientação da superfície `/warmup/*`.

## Entregas
- checklist de ativação no dashboard
- estados vazios inteligentes
- microcopy de confiança em settings
- ajuda contextual nas telas críticas
- jornada mínima de primeiro valor

## Critérios de aceite
- usuário entende o próximo passo em cada tela principal
- estado vazio não parece bug
- ações destrutivas têm contexto e confirmação
