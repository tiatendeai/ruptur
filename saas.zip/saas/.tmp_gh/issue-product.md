## Objetivo
Fechar posicionamento, ICP, taxonomia de trabalho e métricas mestras do SaaS.

## Entregas
- proposta de valor oficial em 1 frase
- ICP primário e secundário
- taxonomia: backlog / débito técnico / demanda nova / operação-transitório
- matriz de priorização executiva
- métricas: tempo até primeiro valor, ativação, retenção, ciclo e classificação correta

## Critérios de aceite
- mensagem única aprovada
- critérios de classificação documentados
- 5 métricas definidas com forma de medição
