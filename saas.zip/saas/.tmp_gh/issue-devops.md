## Objetivo
Formalizar release seguro e reversível do warmup/runtime.

## Entregas
- pipeline mínimo com validação, build, smoke e health gate
- artefato/release versionado
- rollback playbook testável
- matriz de ambientes e variáveis
- diferenciação explícita entre build, runtime e dado volátil

## Critérios de aceite
- release só promove com smoke + health aprovados
- rollback documentado
- ambientes e variáveis mapeados
