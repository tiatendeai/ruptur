## Objetivo
Estruturar base comercial mínima para vender resultado, não arquitetura.

## Entregas
- posicionamento final em 1 frase
- ICP primário recomendado
- landing/comunicação de valor
- hipótese de pricing inicial
- objection handling e playbook comercial mínimo

## Critérios de aceite
- 1 frase de posicionamento aprovada
- ICP definido
- objeções principais respondidas
